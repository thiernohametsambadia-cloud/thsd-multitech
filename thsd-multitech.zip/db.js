const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/thsd_multitech';
  await mongoose.connect(uri);
  console.log('MongoDB connected');
};

module.exports = connectDB;
