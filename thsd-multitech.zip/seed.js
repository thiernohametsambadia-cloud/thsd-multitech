const connectDB = require('./db');
const User = require('./models/User');
const Service = require('./models/Service');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const seed = async () => {
  try {
    await connectDB();

    const adminExists = await User.findOne({ email: 'admin@thsd-multitech.com' });
    if (!adminExists) {
      const hashed = await bcrypt.hash('admin123', 10);
      await User.create({ email: 'admin@thsd-multitech.com', password: hashed });
      console.log('Admin created: admin@thsd-multitech.com / admin123');
    } else {
      console.log('Admin already exists');
    }

    const svcCount = await Service.countDocuments();
    if (svcCount === 0) {
      await Service.insertMany([
        { title: 'Développement Web', description: 'Sites vitrines, applications web, e-commerce et solutions sur mesure.', icon: 'FaGlobe', sort_order: 0 },
        { title: 'Graphic Design', description: "Création d'identités visuelles, logos, chartes graphiques.", icon: 'FaPalette', sort_order: 1 },
        { title: 'Maintenance Informatique', description: 'Assistance technique, dépannage et maintenance de vos équipements.', icon: 'FaLaptopCode', sort_order: 2 },
        { title: 'Formation', description: 'Formations en développement web, design et outils numériques.', icon: 'FaChalkboardTeacher', sort_order: 3 },
      ]);
      console.log('Default services created');
    } else {
      console.log('Services already exist');
    }

    console.log('Seed completed');
  } catch (err) {
    console.error('Seed error:', err);
  } finally {
    process.exit(0);
  }
};

seed();
